<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h2>Menu</h2>
    </div>

    <ul class="sidebar-menu">
        <li><a href="account_management.php">👤 Account Management</a></li>
        <li><a href="manage_borrows.php">📚 Manage Borrows</a></li>
        <li><a href="borrow_history.php">🕘 Borrow History</a></li>
        <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
</div>

<div class="sidebar-overlay" onclick="toggleSidebar()"></div>
